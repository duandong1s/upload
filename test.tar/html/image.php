<?php
session_start();
header('Content-type: image/gif');
$image_w = 140;
$image_h = 45;
$number = range(0, 9);
$character = range("Z", "A");
$result = array_merge($number, $character);
$string = "";
$len = count($result);
for ($i = 0; $i < 6; $i++) {
    $new_number[$i] = $result[rand(0, $len - 1)];
    $string = $string . $new_number[$i];
}
$_SESSION['string'] = $string;
$check_image = imagecreatetruecolor($image_w, $image_h);
$white = imagecolorallocate($check_image, 255, 255, 255);
$black = imagecolorallocate($check_image, 0, 0, 0);
imagefill($check_image, 0, 0, $white);
$line_color = imagecolorallocate($check_image, 255, 0, 0);
imageline($check_image, 0, 10, 150, 50, $line_color);
for ($i = 0; $i < 100; $i++) {
    imagesetpixel($check_image, rand(0, $image_w), rand(0, $image_h), $black);
}
for ($i = 0, $iMax = count($new_number); $i < $iMax; $i++) {
    $x = mt_rand(1, 7) + $image_w * $i / 6;
    $y = mt_rand(1, $image_h / 6);
    $color = imagecolorallocate($check_image, mt_rand(0, 200), mt_rand(0, 200), mt_rand(0, 200));
    imagestring($check_image, 100, $x, $y, $new_number[$i], $color);
}
imagepng($check_image);
imagedestroy($check_image);
?>