<?php
date_default_timezone_set('PRC');
if ($_COOKIE['isLogin'] == 1 && $_COOKIE['username'] != null && $_COOKIE['password'] != null) {
    check($_COOKIE['username'], $_COOKIE['password']);
} else {
    echo "<script>top.location = './login.php';</script>";
}

$saveExt = 'zip';
$saveFolder = 'uploads';
if (isset($_SERVER['REQUEST_METHOD']) && strtoupper($_SERVER['REQUEST_METHOD']) === 'POST') {
    $filename = $_FILES['file']['name'];
    $temp_name = $_FILES['file']['tmp_name'];
    $size = $_FILES['file']['size'];
    $error = $_FILES['file']['error'];
    $ip = $_SERVER["REMOTE_ADDR"];
    if ($size > 2 * 1024 * 1024 * 1024) {
        //
        echo "fail,try again!";
        exit();
    }
    $time = date('Y-m-d H:i:s');
    $arr = pathinfo($filename);
    $ext_suffix = $arr['extension'];
    $allow_suffix = array('zip', 'tar.gz', 'rar', '7z', 'tar');
    if (!in_array($ext_suffix, $allow_suffix)) {
        echo "fail,try again!";
        exit();
    }
    if (!file_exists($saveFolder)) {
        if (!mkdir($saveFolder) && !is_dir($saveFolder)) {
            throw new \RuntimeException(sprintf('Directory "%s" was not created', $saveFolder));
        }
    }
    $formatSize = formatBytes($size);
    $delExtName = str_replace(strstr($filename, "."), "", $filename);
    if (strlen($delExtName) >= 10) {
        $filename = substr($delExtName, 0, 8) . '.' . $ext_suffix;
    }
    $new_filename = create_uuid() . '.' . $saveExt;
    if (move_uploaded_file($temp_name, $saveFolder . '/' . $new_filename)) {
        saveFileToDB($filename, $new_filename, $time, $ip, $formatSize);
        echo "fail,try again";
    } else {
        echo "fail,try again!";
    }
} else {
    echo "Request method is not allowed！";
}

function create_uuid($prefix = "")
{
    $chars = md5(uniqid(mt_rand(), true));
    $uuid = substr($chars, 0, 8) . '-'
        . substr($chars, 8, 4) . '-'
        . substr($chars, 12, 4) . '-'
        . substr($chars, 16, 4) . '-'
        . substr($chars, 20, 12);
    return $prefix . $uuid;
}


function formatBytes($size)
{
    $units = array(' B', ' KB', ' MB', ' GB', ' TB');
    for ($i = 0; $size >= 1024 && $i < 4; $i++) {
        $size /= 1024;
    }
    return round($size, 2) . $units[$i];
}

function saveFileToDB($savename, $rawname, $time, $sourceip, $formatSize)
{
    $db = new PDO('sqlite:mysqlitedb.db');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "INSERT INTO upload_data VALUES(:savename, :rawname, :time, :sourceip, :formatSize)";
    try {
        $statement = $db->prepare($sql);
        $statement->execute(array('savename' => $savename, 'rawname' => $rawname, 'time' => $time,
            'sourceip' => $sourceip, 'formatSize' => $formatSize));
        $statement->fetch();
    } catch (PDOException $e) {
        echo "Something went wrong:" . $e->getMessage();
    }
}
function check($user, $pass)
{
    $db = new PDO('sqlite:../mysqlitedb.db');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $username = $user;
    $password = $pass;
    $sql = "SELECT * FROM users WHERE user_name = :name AND user_password = :pass";
    try {
        $statement = $db->prepare($sql);
        $statement->execute(array('name' => $username, 'pass' => $password));
        $row = $statement->fetch();
        if ($row['user_name'] == $username && $row['user_password'] == $password) {
            setcookie("username", $username, time() + 600 * 3);
            setcookie("password", $password, time() + 600 * 3);
            setcookie("isLogin", 1);
        } else {
            echo "<script>top.location = './login.php';</script>";
        }
    } catch (PDOException $e) {
        echo "Something went wrong:" . $e->getMessage();
    }
}
?>