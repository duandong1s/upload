<!DOCTYPE HTML>
<html lang="zxx">

<head>
    <title>File storage system-Login</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8"/>
    <meta name="keywords" content=""
    />
    <script>
        function changeCode() {
            var code = document.getElementById("code");
            code.src = 'image.php?tm=' + Math.random();
        }

        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <link rel="stylesheet" href="css/style_login.css" type="text/css" media="all"/>
    <link rel="stylesheet" href="css/font-awesome.min.css">

</head>

<body>
<div id="bg">
    <canvas></canvas>
    <canvas></canvas>
    <canvas></canvas>
</div>
<h1>Welcome Login</h1>
<div class="sub-main-w3">
    <form action="#" method="post">
        <h2>Login Now
            <i class="fas fa-level-down-alt"></i>
        </h2>
        <div class="form-style-agile">
            <label>
                <i class="fas fa-user"></i>
                Username
            </label>
            <input placeholder="Username" name="username" type="text" required="">
        </div>
        <div class="form-style-agile">
            <label>
                <i class="fas fa-unlock-alt"></i>
                Password
            </label>
            <input placeholder="Password" name="password" type="password" required="">
        </div>
        <div class="form-style-agile">
            <label>
                <i class="fas fa-image"></i>
                Verification Code
            </label>
            <div class="wthree-text">
                <ul>
                    <li>
                        <input placeholder="code" name="code" type="text" required="">
                    </li>
                    <li>
                        <img src="image.php" id="code" onclick="changeCode()">
                    </li>
                </ul>
            </div>

        </div>
        <!-- checkbox -->
        <div class="wthree-text">
            <ul>
                <li>
                    <label class="anim">
                        <span id="warning" style="color: red"></span>
                    </label>
                </li>
                <li>
                    <a href="rePasswd.php">Modify Password?</a>
                </li>
            </ul>
        </div>
        <input type="submit" name="ok" value="Log In">
    </form>
</div>

<div class="footer">
    <p>Copyright &copy; 2022<a target="_blank" href="#"></a>
    </p>
</div>

<script src="js/jquery.min.js"></script>

<script src="js/canva_moving_effect.js"></script>

</body>

<?php
session_start();

if ($_COOKIE['isLogin'] == 1 && $_COOKIE['username'] != null && $_COOKIE['password'] != null) {
    check($_COOKIE['username'], $_COOKIE['password']);
}

if (isset($_POST['ok'])) {
    $checkstr = $_SESSION['string'];
    $str = $_POST['code'];
    if (strcasecmp($str, $checkstr) == 0) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        check($username, $password);
    } else {
        echo "<script>var warning = document.getElementById('warning');
        warning.innerHTML = 'Verification code error！';
        changeCode();
                </script>;
        ";
    }

}
function check($user, $pass)
{
    $db = new PDO('sqlite:../mysqlitedb.db');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $username = $user;
    $password = $pass;
    $sql = "SELECT * FROM users WHERE user_name = :name AND user_password = :pass";
    try {
        $statement = $db->prepare($sql);
        $statement->execute(array('name' => $username, 'pass' => $password));
        $row = $statement->fetch();
        if ($row['user_name'] == $username && $row['user_password'] == $password) {
            echo "<script>window.location.href='index.php'; changeCode();</script>";
            setcookie("username", $username, time() + 600 * 3);
            setcookie("password", $password, time() + 600 * 3);
            setcookie("isLogin", 1);
        } else {
            echo "<script>var warning = document.getElementById('warning');
        warning.innerHTML = 'Username or password error！';
        changeCode();
                </script>;
        ";
        }
    } catch (PDOException $e) {
        echo "Something went wrong:" . $e->getMessage();
    }
}

?>
</html>