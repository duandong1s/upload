<!DOCTYPE html>
<?php
header("Content-type: text/html; charset=utf-8");
$header_name = 'Source code repository';
$username = $_COOKIE['username'];

if ($_COOKIE['isLogin'] == 1 && $_COOKIE['username'] != null && $_COOKIE['password'] != null) {
    check($_COOKIE['username'], $_COOKIE['password']);
} else {
    echo "<script>top.location = './login.php';</script>";
}

function check($user, $pass)
{
    $db = new PDO('sqlite:../mysqlitedb.db');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $username = $user;
    $password = $pass;
    $sql = "SELECT * FROM users WHERE user_name = :name AND user_password = :pass";
    try {
        $statement = $db->prepare($sql);
        $statement->execute(array('name' => $username, 'pass' => $password));
        $row = $statement->fetch();
        if ($row['user_name'] == $username && $row['user_password'] == $password) {
            setcookie("username", $username, time() + 600 * 3);
            setcookie("password", $password, time() + 600 * 3);
            setcookie("isLogin", 1);
        } else {
            echo "<script>top.location = './login.php';</script>";
        }
    } catch (PDOException $e) {
        echo "Something went wrong:" . $e->getMessage();
    }
}

function showFiles()
{
    $db = new PDO('sqlite:../mysqlitedb.db');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql = "SELECT * FROM upload_data";
    try {
        $statement = $db->prepare($sql);
        $statement->execute(array());
        $file_items = [];
        while ($row = $statement->fetch()) {
            $file_item = array();
            $file_item['savename'] = $row['savename'];
            $file_item['rawname'] = $row['rawname'];
            $file_item['filesize'] = $row['filesize'];
            $file_item['uploadtime'] = $row['uploadtime'];
            $file_item['sourceip'] = $row['sourceip'];
            $file_items[] = $file_item;
        }
        return $file_items;
    } catch (PDOException $e) {
        echo "Something went wrong:" . $e->getMessage();
    }
}

$file_item = showFiles();
?>
<html>
<head>
    <title>File storage system-Index</title>
    <link rel="shortcut icon" href="img/logo.png"/>
    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" href="css/font-awesome.min.css"/>
    <link rel="stylesheet" href="css/style.css"/>
    <link rel="stylesheet" href="css/prism.css"/>
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/prism.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
<body>
<div id="page-navbar" class="path-top navbar navbar-default navbar-fixed-top">
    <p class="navbar-text" style="float: right">
        <a href="javascript:logout()" style="text-decoration: none">Exit?</a>
    </p>
    <p class="navbar-text" style="float: right">
        <i class="fas fa-user-circle"></i><?php echo '  Welcome user：' . $username ?>
    </p>
    <p class="navbar-text" style="float: left">
        <i class="fas fa-desktop"></i>
        <span class="header-time-span1" id="Time1"></span>
        <!--        <span class="header-time-span2 middle" id="Time2"></span>-->
        <span class="header-time-span3 middle" id="Time3"></span>
    </p>
    <div class="container">

    </div>
</div>
<div class="path-announcement navbar navbar-default navbar-fixed-top">
    <div class="path-announcement2 container">
        <p><i class="fa fa-volume-down"></i><?php echo $header_name; ?></p>
    </div>
</div>
<div class="container" id="container_top">
    <div class="page-content container" id="container_page">
        <div id="directory-list-header">
            <div class="row">
                <div class="col-md-2 col-sm-6 col-xs-10 text-center">
                    <i class="fas fa-folder-open"></i> Original Filename
                </div>
                <div class="col-md-2 col-sm-6 col-xs-10 text-center">
                    <i class="fas fa-folder"></i> Storage Filename
                </div>
                <div class="col-md-2 col-sm-6 col-xs-10 text-center">
                    <i class="fas fa-database"></i> File Size
                </div>
                <div class="col-md-2 col-sm-6 col-xs-10 text-center">
                    <i class="fas fa-calendar-alt"></i> Upload Time
                </div>
                <div class="col-md-2 col-sm-6 col-xs-10 text-center">
                    <i class="fas fa-wifi"></i> Source IP
                </div>
                <div class="col-md-2 col-sm-6 col-xs-10 text-center">
                    <i class="fas fa-cog"></i> Operation
                </div>
            </div>
        </div>
        <ul id="directory-listing" class="nav nav-pills nav-stacked" style="margin-top: 20px; text-align: center">
            <?php foreach ($file_item as $index => $fileInfo): ?>
                <li>
                    <div class="row">
                        <div class="col-md-2 col-sm-6 col-xs-10 text-left">
                            <span>ITEM-<?php echo $index + 1 ?>：</span>
                            <i class="fa fa-file-alt fa-fw"></i>
                            <span><?php echo $fileInfo['savename'] ?></span>
                        </div>
                        <div class="col-md-2 col-sm-6 col-xs-10 text-center">
                            <span style="overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:1;"><?php echo $fileInfo['rawname'] ?></span>
                        </div>
                        <div class="col-md-2 col-sm-6 col-xs-10 text-center">
                            <span><?php echo $fileInfo['filesize'] ?></span>
                        </div>
                        <div class="col-md-2 col-sm-6 col-xs-10 text-center">
                            <span><?php echo $fileInfo['uploadtime'] ?></span>
                        </div>
                        <div class="col-md-2 col-sm-6 col-xs-10 text-center">
                            <span><?php echo $fileInfo['sourceip'] ?></span>
                        </div>
                        <div class="col-md-2 col-sm-6 col-xs-10 text-center">
                            <a href="javascript:downloadWarn('<?php echo $fileInfo['savename'] ?>', '<?php echo $fileInfo['rawname'] ?>')"
                               style="text-decoration: none"><i
                                        class="fas fa-download"></i> Download</a>
                        </div>
                    </div>
                </li>

            <?php endforeach; ?>
        </ul>
    </div>

    <hr id="footer_hr" style="margin-bottom: 40px;"/>
    <script type="text/javascript">
        function getTime() {
            let date1 = new Date()
            let year = date1.getFullYear()
            let month = date1.getMonth()
            let day = date1.getDate()
            let hh = date1.getHours()
            let mm = date1.getMinutes()
            let ss = date1.getSeconds()
            let date = year + ' ' + (month + 1) + '-' + day + ' '
            let realTime = hh + ':' + mm + ':' + ss
            document.getElementById('Time1').innerHTML = date
            document.getElementById('Time3').innerHTML = realTime
        }

        var nowtime = 0;
        nowtime = setInterval(() => {
            getTime()
        }, 1000);

        window.onload = function () {
            changeDivHeight();
        }
        window.onresize = function () {
            changeDivHeight();
        }

        function logout() {
            if (confirm('Are you sure to exit?')) {
                var keys = document.cookie.match(/[^ =;]+(?=\=)/g);
                if (keys) {
                    for (var i = keys.length; i--;)
                        document.cookie = keys[i] + '=0;expires=' + new Date(0).toUTCString()
                }
                top.location = "./login.php";
            }
            return false;
        }

        function downloadWarn(filename, storageFileName) {
            if (confirm('Confirm download ' + filename + '？')) {
                downloadFile(filename, storageFileName)
            }
        }

        function downloadFile(filename, storageFileName) {
            var baseurl = '/uploads/'
            var url = baseurl + storageFileName;
            var xhr = new XMLHttpRequest();
            xhr.open('GET', url, true);
            xhr.responseType = "blob";
            xhr.onload = function () {
                if (this.status === 200) {
                    var blob = this.response;
                    var reader = new FileReader();
                    reader.readAsDataURL(blob);
                    reader.onload = function (e) {
                        var a = document.createElement('a');
                        a.download = filename;
                        a.href = e.target.result;
                        $("body").append(a);
                        a.click();
                        $(a).remove();
                    }
                }
            };
            xhr.send()
        }

        function changeDivHeight() {
            if (document.getElementById("container_readme")) {
                container_readme.style.marginBottom = '0';
            }

            ScrollHeight_body = document.body.offsetHeight;
            InnerHeight_window = window.innerHeight;
            container_top.style.minHeight = '0';
            ClientHeight_top = container_top.clientHeight + 60;
            ClientHeight_top1 = ClientHeight_top + 69;
            ClientHeight_top2 = ClientHeight_top1 - 60;

            container_top.style.minHeight = '';

            if (ScrollHeight_body > ClientHeight_top2) {
                footer_hr.style.marginTop = '0';
            } else {
                footer_hr.style.marginTop = '40px';
            }

            if (ScrollHeight_body > InnerHeight_window) {
                if (ClientHeight_top > InnerHeight_window) {
                    container_top.style.marginBottom = '0';
                    container_page.style.marginBottom = '0';
                    if (document.getElementById("container_readme")) {
                        container_readme.style.marginTop = '20px';
                    }
                } else {
                    footer_hr.style.marginTop = '40px';
                    container_top.style.marginBottom = '';
                    container_page.style.marginBottom = '';
                    if (document.getElementById("container_readme")) {
                        container_readme.style.marginTop = '';
                    }
                }
            } else {
                if (ScrollHeight_body < ClientHeight_top1) {
                    container_top.style.marginBottom = '0';
                    container_page.style.marginBottom = '0';
                    if (document.getElementById("container_readme")) {
                        container_readme.style.marginTop = '20px';
                    }
                } else {
                    footer_hr.style.marginTop = '40px';
                    container_top.style.marginBottom = '';
                    container_page.style.marginBottom = '';
                    if (document.getElementById("container_readme")) {
                        container_readme.style.marginTop = '';
                    }
                }
            }
        }
    </script>
</body>
</html>
